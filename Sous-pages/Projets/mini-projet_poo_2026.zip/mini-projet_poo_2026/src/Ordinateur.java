package projet;
import java.util.Random;

public class Ordinateur extends Joueur{
    private final Random seed;

    Ordinateur(String nom){
        super(nom);
        this.seed= new Random();
    }
    @Override
    public Carte choixCarte(){
        int cur=0; int[][] cooCartes= new int[16][2];
        // Les coordonnées de chaque case prise est gardée en mémoire
        // Le tableau est parcouru et toutes les cases contenant des cartes choisissables sont enregistrées
        for(int x=0;x<4;x++){
            for(int y=0;y<4;y++){
                if(!this.grille.obtenirCarte(x,y).estVisible()){
                    cooCartes[cur][0]= x;
                    cooCartes[cur][1]= y;
                    cur++;
                }
            }
        }
        // Tirage aléatoire d'une carte parmi celles enregistrées
        int choix= this.seed.nextInt(cur);
        return super.grille.retirerCarte(cooCartes[choix][0],cooCartes[choix][1]);
    }

    @Override
    public int choixCentre(int taille,Carte[] centre){  //Choix aléatoire d'une carte au centre'
        System.out.printf("%s\n", super.grille.toString());
        return this.seed.nextInt(taille)%taille;
    }

    @Override 
    public Directions choixDirection(){
        int choix=this.seed.nextInt(4)%4; int boucle=0; //Choix d'une direction aléatoire
        Directions dir=null;
        // Test de toutes les directions jusqu'à en trouver une valide (variable choix incrémentée de la direction si non valide)
        while(!this.grille.DirectionValide(dir)){
            choix= (choix+1)%4;
            if(boucle>3){throw new Illegal­State­Exception("Aucune direction n'est valide selon cette grille.");}
            // Erreur si aucune direction valide trouvée (Arrêt du programme)
            boucle++;
            dir= switch(choix){
                case 0 -> Directions.HAUT;
                case 1 -> Directions.GAUCHE;
                case 2 -> Directions.BAS;
                case 3 -> Directions.DROITE;
                default -> null;};
        }
        System.out.println("Carte insérée.");
        return dir;
    }

    @Override
    public boolean estHumain(){return false;}
    @Override
    public String toString(){
        return String.format("\033[94m[Ordinateur] "+this.nom()+"\033[0m");
    }
}
