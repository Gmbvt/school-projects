package projet;
public enum Directions{
    HAUT,
    BAS,
    GAUCHE,
    DROITE
}