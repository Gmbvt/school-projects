package projet;


public class Grille{
    private final Case caseDebut;       // La première case sera conservée. Les autres cases sont définies par voisinage de la première.
    private final int coordonneesCaseVide[] = {-1, -1}; // La case vide ne contient aucune carte

    Grille(Carte[] tableauCartes){
        this.caseDebut = new Case(tableauCartes[0]);
        remplirGrille(4, tableauCartes);
    }


    private void remplirGrille(int n, Carte[] tableauCartes){        
        for(int i = 0; i < n; i++){     // Pour chaque ligne : 
            for(int j = 0; j < n; j++){ // Pour chaque colonne :
                if(j != 0){ // Si la case n'est pas sur un bord, la case adjacente est créee comme voisin de cette case (HAUT, BAS, GAUCHE, DROITE), 
                            // Cette case sera définie comme voisin de direction opposés de la case adjacente (Matrice doublement chaînée)
                    this.obtenirCase(i, j).ajouterVoisins(obtenirCase(i, j-1), Directions.GAUCHE);
                    this.obtenirCase(i, j).voisinDe(Directions.GAUCHE).ajouterVoisins(this.obtenirCase(i, j), Directions.DROITE);
                }
                if(j != n-1){
                    if(this.obtenirCase(i, j+1) == null){   // Si la case ne possède pas de voisin (Case voisine nulle), création du voisin 
                        this.obtenirCase(i, j).ajouterVoisins(new Case(tableauCartes[n*i+j+1]), Directions.DROITE);
                    }
                    else{                                   // Complétion du chaînage sinon
                        this.obtenirCase(i, j).ajouterVoisins(obtenirCase(i, j+1), Directions.DROITE);
                    }
                }
                if(i != 0){ //Fonctionnement analogue pour les directions HAUT, BAS
                    this.obtenirCase(i, j).ajouterVoisins(this.obtenirCase(i-1, j), Directions.HAUT);
                    this.obtenirCase(i, j).voisinDe(Directions.HAUT).ajouterVoisins(this.obtenirCase(i, j), Directions.BAS);
                    
                }
                if(i != n-1){
                    
                    if(this.obtenirCase(i+1, j) == null){
                        this.obtenirCase(i, j).ajouterVoisins(new Case(tableauCartes[n*(i+1)+j]), Directions.BAS);
                    }
                    
                    else{
                        this.obtenirCase(i, j).ajouterVoisins(obtenirCase(i+1, j), Directions.BAS);
                    }
                    
                }

            }
        }
    }

    private Case chercherCase(int i, int j, Case caseAChercher){    // Méthode récursive, prend en entrée un ligne et une colonne, et une case
        if(caseAChercher == null){                                  
            return null;
        }
        else{                                                      
            if(j > 0){                                              // Si la colonne est supérieure à 0, appel récursif de la méthode en décrémentant la colonne et en prenant comme case à chercher le voisin de DROITE
                return this.chercherCase(i, j-1, caseAChercher.voisinDe(Directions.DROITE));
            }        
            else if (i > 0){                                        // Si la ligne est supérieure à 0, appel récursif de la méthode en décrémentant la ligne et en prenant comme case à chercher le voisin du BAS
                return this.chercherCase(i-1, j, caseAChercher.voisinDe(Directions.BAS));
            }
            else{                                                   // Si la ligne et la colonne sont nulles, la case à chercher est renvoyée
                return caseAChercher;
            }
        }
        
    }
    public Case obtenirCase(int i, int j){                          // Appel de la méthode chercherCase en prenant comme case à chercher la première case, cette fonction sera celle utilisée pour chercher une case à partir
        return chercherCase(i, j, this.caseDebut);                  // de ses coordonnées
    }

    public Carte obtenirCarte(int i, int j){                        // Retour de la carte dans la case des coordonnées demandées
        return this.obtenirCase(i, j).obtenirCarte();
    }


    @Override
    public String toString(){
        String resultat="";
        for(int i=0; i<4; i++){
            for(int j=0; j<4; j++){
                Case caseActuelle = this.obtenirCase(i,j);
                if(caseActuelle.estVide()){
                    resultat += "   ";
                }
                else{
                    resultat += this.obtenirCarte(i,j).toString() + ' ';
                }
            }
            resultat+='\n';
            
        }
        return resultat;
    }

    public int calculScore(){
        int score = 0;
        Case caseActuelle;
        for(int i = 0; i < 4; i++){                     // Toutes les cartes ayant un voisin de même valeur n'ajoutent pas de points
            for (int j = 0; j < 4; j++){
                score += this.obtenirCase(i, j).score();
            }
        }
        return score;
    }

    public Carte retirerCarte(int i, int j){            // Les coordonnées de la carte à retirer sont sauvegardées comme coordonnées de la case vide (ne contenant aucune carte)
        this.coordonneesCaseVide[0] = i;
        this.coordonneesCaseVide[1] = j;
        return this.obtenirCase(i, j).retirerCarte();   // Renvoie la carte retirée de la case
    }

    public void inserer(Carte carte, Directions dir){   // Le décalage commence à partir d'un bord, (bord BAS pour HAUT, GAUCHE pour DROITE, ...) sur la même ligne/collonne que la case vide
        int i = this.coordonneesCaseVide[0];
        int j = this.coordonneesCaseVide[1];
        
        if(dir == Directions.HAUT){
            this.obtenirCase(3, j).decaler(carte, dir);
        }
        if(dir == Directions.BAS){
            this.obtenirCase(0, j).decaler(carte, dir);
        }
        if(dir == Directions.GAUCHE){
            this.obtenirCase(i, 3).decaler(carte, dir);
        }
        if(dir == Directions.DROITE){
            this.obtenirCase(i, 0).decaler(carte, dir);
        }
    }

    public boolean DirectionValide(Directions dir){ // La direction valide concerne le cas où la case vide se trouve sur un bord, le jeu interdit de placer directement une carte sur la case vide
        int i = this.coordonneesCaseVide[0];
        int j = this.coordonneesCaseVide[1];
        return !((dir == Directions.HAUT && i == 3) || (dir == Directions.BAS && i == 0) || (dir == Directions.DROITE && j == 0) || (dir == Directions.GAUCHE && j == 3) || dir == null);
    }
}
