package projet;

public class Carte{
    private boolean estVisible;  // Les valeurs des cartes non-visibles ne sont pas montrées
    private final int valeur;

    Carte(int valeur){
        this.valeur = valeur;
        this.estVisible = false;
    }

    public int valeur(){
        return this.valeur;
    }
    public boolean estVisible(){
        return this.estVisible;
    }
    public void retourner(){    // Si une carte est visible, elle est rendue non visible, et inversement 
        this.estVisible = !this.estVisible;
    }
    @Override
    public String toString(){
        if(this.estVisible()){
            String couleur = switch(this.valeur()){
                case 1 ->  "\033[90m";
                case 2 ->  "\033[37m";
                case 3 ->  "\033[34m";
                case 4 ->  "\033[35m";
                case 5 ->  "\033[95m";
                case 6 ->  "\033[94m";
                case 7 ->  "\033[92m";
                case 8 ->  "\033[33m";
                case 9 ->  "\033[93m";
                case 10 -> "\033[31m";
                default -> "";};
            return couleur + String.format("%02d", this.valeur()) + "\033[0m";
        }
        else{
            return "**";    // Carte non-visible
        }
    }
}
