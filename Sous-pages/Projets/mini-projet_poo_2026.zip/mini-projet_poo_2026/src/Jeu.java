package projet;
import java.util.Random;

public class Jeu{
    private int ordre;
    private int tour;
    private final int nbJoueurs;
    private final Joueur[] joueurs;
    private Carte[] centre;

    Jeu(int nbJoueurs,Joueur[] joueurs){
        this.ordre=-1;
        this.tour=0;
        this.nbJoueurs=nbJoueurs;
        this.joueurs= joueurs.clone();
        this.centre= new Carte[nbJoueurs];
    }

    private Carte[] creerPioche(){
        // Initialisation de la pioche, toutes les cartes de valeur 1 à 10 sont créées en 10 exemplaires
        Carte[] pioche= new Carte[100];
        for(int i=0;i<10;i++){
            for(int j=0;j<10;j++){
                pioche[i*10+j]=new Carte(i+1);
            }
        }

        // Mélange de la pioche : deux cartes aléatoires dans la pioche sont interchangées; l'opération est répétée 10000 fois.
        Random seed= new Random();
        int x,y;
        Carte tmp;
        for(int i=0;i<10000;i++){
            x=seed.nextInt(100)%100; // Deux cartes sont prises aléatoirement, avec un indice compris entre 0 et 99 inclus. 
            y=seed.nextInt(100)%100; // L'indice est la place de la carte dans la pioche.
            tmp=pioche[x];
            pioche[x]=pioche[y];
            pioche[y]=tmp;
        }
        return pioche;
    }

    private void jouerPartie(){
        // Fonction appellée une fois par partie, car responsable de la partie elle-même
        System.out.println("----- Début de la partie. -----");

        // Création d' une pioche temporaire, le temps de distribuer les cartes aux joueurs
        Carte[] pioche= this.creerPioche();
        // Une fois la pioche mélangée, il suffit de prendre chaque joueur pour la distribuer.
        for(int i=0;i<this.nbJoueurs;i++){
                Carte[] distribuer = new Carte[16]; // Liste intermédiaire pour distribuer facilement
                for(int k=0;k<16;k++){ // Il faut distribuer 16 cartes par joueur. 
                    distribuer[k] = pioche[(i*16)+k];
                }
                // Les cartes sont placées dans un tableau de cartes pour être placées dans la grille de chaque joueur
                this.joueurs[i].initCartes(distribuer);
            }

        // Début de la partie
        while(this.tour<16){ // Le jeu se finit obligatoirement au bout de 16 tours
            this.jouerTour();
        }
        System.out.printf("%n--- Fin de la partie ---%n");
        // Calcul des scores de chaque joueur
        int[] scores= new int[this.nbJoueurs];
        for(int i=0;i<this.nbJoueurs;i++){
            scores[i]=this.joueurs[i].calculerScore();
        }
        // Tri du score de chaque joueur par ordre croissant (le gagnant a marqué le moins de points)
        int tmpScore; Joueur tmpJoueur;
        for(int i=0;i<this.nbJoueurs;i++){
            for(int j=0;j<this.nbJoueurs;j++){
                if(scores[i]<scores[j]){
                    // Echange de 2 joueurs
                    tmpScore = scores[i];
                    tmpJoueur= this.joueurs[i];
                    scores[i] = scores[j] ; scores[j]=tmpScore;
                    this.joueurs[i] = this.joueurs[j]; this.joueurs[j] = tmpJoueur;
                }
            }
        }
        // Les scores de chaque joueur dans l'ordre croissant est affiché.
        System.out.printf("Scores :%n");
        for(int i=0;i<this.nbJoueurs;i++){
            System.out.printf("%d- %s avec %d points%n",i+1,this.joueurs[i].toString(),scores[i]);
        }
    }

    private void jouerTour(){
        // Cette fonction est appelée à chaque tour de jeu
        this.tour++; this.ordre++; // On incrémente les compteurs de tour et d'ordre des joueurs.
        System.out.printf("%n--- Tour %d ---%n",this.tour);
        
        // Pour chaque joueur, choix de la carte à retirer dans leur grille
        for(int i=0;i<this.nbJoueurs;i++){
            Joueur joueurCourant = this.joueurs[(i+this.ordre)%this.nbJoueurs];
            System.out.printf("C'est à %s de retirer une carte de leur grille.%n",joueurCourant.toString());
            this.centre[i]= joueurCourant.retirerCarte();
            System.out.printf("Carte retirée : [%s].%n---%n",this.centre[i]);
        }
        System.out.printf("%n---%n");
        // Il faut maintenant que chaque joueur reprenne une carte du centre
        int nbCartesCentre=this.nbJoueurs;
        for(int i=0;i<this.nbJoueurs;i++){
            Joueur joueurCourant = this.joueurs[(i+this.ordre)%this.nbJoueurs];
            System.out.printf("C'est à %s de piocher une carte du centre et de l'insérer dans leur grille.%n",joueurCourant.toString());
            joueurCourant.piocherCarte(nbCartesCentre,this.centre);
            // Un joueur vient de prendre une carte du centre, décrémentation du nombre de cartes
            nbCartesCentre--;
            System.out.printf("---%n");
        }
    }




    public static void main(String[] args) {
        System.out.println("-- Simulation du jeu Dékal --");

        boolean jouer= true;
        // Une boucle true, chaque boucle est une partie différente.
        // Déclaration (et initialisation) en clair toutes les variables nécessaires
        int nbJoueurs=-1;
        int nbHumains=-1;
        Joueur[] joueurs;
        Jeu game;


        System.out.println("Début d'une nouvelle partie");
        System.out.println("Nombre de joueurs participants [2-6]");
            
        // Tant que l'utilisateur ne donne pas un nombre de joueur approprié:
        while(nbJoueurs>6 || nbJoueurs<2){
            try{
                nbJoueurs=Integer.parseInt(System.console().readLine());
            } catch(NumberFormatException e){
                nbJoueurs=-1; // Si l'utilisateur ne donne pas de chiffre, la réponse est traité comme un chiffre invalide
            }
            if(nbJoueurs>6 || nbJoueurs<2){
                System.out.println("Nombre de joueur [2-6] invalide.");
            }
        }

        joueurs= new Joueur[nbJoueurs];
        System.out.printf("Nombre de joueurs humains [0-%d]%n",nbJoueurs);

        // Tant que l'utilisateur ne nous donne pas un nombre d'humains approprié:
        while(nbHumains>nbJoueurs || nbHumains<0){
            try{
                nbHumains=Integer.parseInt(System.console().readLine());
            } catch(NumberFormatException e){
                nbHumains=-1; // Si l'utilisateur ne donne pas de chiffre, la réponse est traité comme un chiffre invalide
            }
            if(nbHumains>nbJoueurs || nbHumains<0){
                System.out.printf("Nombre de joueurs humain [0-%d] invalide.", nbJoueurs);
            }
        }
        
            
        // Initialisation des joueurs
        for(int i=0;i<nbJoueurs;i++){
            if(i<nbHumains){
                System.out.printf("Nom du joueur %d (Humain) : ", i+1);
                joueurs[i]= new Humain(System.console().readLine());
            }
            else{
                System.out.printf("Nom du joueur %d (Ordinateur) : ", i+1);
                joueurs[i]= new Ordinateur(System.console().readLine());
            }
        }

        // Début de la partie, création d'une instance game de la classe Jeu et appel de la méthode jouerPartie()
        game= new Jeu(nbJoueurs,joueurs);
        game.jouerPartie();

        // La partie est terminée
        System.out.println("Fin de la partie.");
        System.out.printf("Simulation du jeu Dékal, programme réalisé dans le cadre du mini-projet Programmation Orientée Objet Licence 2 Informatique, 2026%nBEUVOT Guillaume%nFrançois LASOTA%n");
    }
}
