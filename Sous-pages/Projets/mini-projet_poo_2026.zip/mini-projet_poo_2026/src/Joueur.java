package projet;

public abstract class Joueur{
    private final String nom;
    public Grille grille;

    Joueur(String nom){this.nom=nom;}
    public String nom(){return this.nom;}
    public void initCartes(Carte[] cartes){
        this.grille = new Grille(cartes);
    }

    public Carte retirerCarte(){
        Carte tmp=this.choixCarte(); // Une carte est choisie, rendue visible puis renvoyée
        tmp.retourner();
        return tmp;
    }

    public void piocherCarte(int taille,Carte[] centre){
        // Sélection de la carte parmi celles du centre (Cumul de celles picohée dans les grilles de chaque joueur)
        int choix = choixCentre(taille,centre);
        // La carte est retirée du cenctre, tout en gardant l'intégrité du centre (pas de case vide)
        Carte carteRetiree= centre[choix];
        for(int i=choix;i<taille-1;i++){
            centre[i]=centre[i+1];
        }
        centre[taille-1]= null;

        // La carte est insérée dans la grille du joueur en utilisant la méthode choixDirection()
        Directions direction= choixDirection();
        this.grille.inserer(carteRetiree,direction);
    }

    public abstract int choixCentre(int taille,Carte[] centre);
    public abstract Carte choixCarte();
    protected abstract Directions choixDirection();
    public int calculerScore(){return this.grille.calculScore();}
    public abstract boolean estHumain();
}
