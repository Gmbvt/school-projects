package projet;

public class Humain extends Joueur{
    Humain(String nom){
        super(nom);
    }

    @Override
    public Carte choixCarte(){
        int x=-1 , y = -1;
        boolean problemeReponse,valide= false;

        while(!valide){
            System.out.printf("%n%s%n",this.grille.toString());
            
            try{
                System.out.printf("Ligne de la carte à retirer [1-4] : ");
                x= Integer.parseInt(System.console().readLine()) -1;
                System.out.printf("Colonne de la carte à retirer [1-4] : ");
                y= Integer.parseInt(System.console().readLine()) -1 ;
                problemeReponse=false;
            } catch(NumberFormatException e){
                x= -1; y= -1; problemeReponse= true;
            }
            if(problemeReponse){
                System.out.println("Seul des chiffres entiers sont acceptés");
            }
            else if(x<0 || y<0 || x>3 || y>3){ /* Les coordonnées maximales de la grille */
                System.out.println("Carte hors de la grille");
            }
            else if(this.grille.obtenirCarte(x,y).estVisible()){
                System.out.println("Carte déjà visible");
            }
            else{
                valide= true;
            }
        }
        // Si une carte vailde est selectionnée, appel de la méthode retirerCarte() de la grille du joueur.
        return this.grille.retirerCarte(x,y);
    }

    @Override
    public int choixCentre(int taille,Carte[] centre){
        if(taille>1){
            System.out.printf("%n%s",this.grille.toString());
            System.out.printf("Cartes disponibles :\n", taille);
            for(int i=0;i<taille;i++){
                System.out.printf("%d:[%s] ",i+1,centre[i].toString());
            }
            System.out.printf("%nChoix d'une carte parmi celles du centre [1-%d] : ",taille);
            int reponse = -1;
            while(reponse < 0 || reponse > taille-1){
                try{
                    reponse= Integer.parseInt(System.console().readLine())-1;
                } catch(NumberFormatException e){}
                // Si la réponse n'est pas un entier, réponse traitée comme invalide
                if(reponse < 0 || reponse > taille-1){
                    System.out.printf("Réponse invalide, saisir un entier entre 1 et %d (inclus) : ",taille);
                }
            }
            System.out.printf("Carte : [%s].%n",centre[reponse].toString());
            return reponse;
        } else{
            System.out.printf("Carte : [%s].%n%n",centre[0].toString());
            return 0;
        }
    }

    
    @Override 
    protected Directions choixDirection(){
        // Affichage de la grille
        System.out.printf("%nGrille de %s:%n%s%n", this.nom(),this.grille.toString());
        boolean valide= false;String reponse=null;Directions dir=null;
        System.out.println("Veuillez choisir la Direction dans laquelle décaler.");
        while(!valide){
            // Si on a reçu un mauvais input, on l'explicite au début de la boucle
            // On le remarque si la reponse a été initialisée
            if(reponse!=null){
                System.out.println("Réponse invalide");
            }
            System.out.println("Décaler vers:");
            System.out.println("  z: le haut");
            System.out.println("  q: la gauche");
            System.out.println("  s: le bas");
            System.out.println("  d: la droite");
            reponse= System.console().readLine();

            // Détection de la direction selectionnée
            dir = switch (reponse) {
                case "z" -> Directions.HAUT;
                case "q" -> Directions.GAUCHE;
                case "s" -> Directions.BAS;
                case "d" -> Directions.DROITE;
                default -> null;};
            // Vérification de la validité
            valide= this.grille.DirectionValide(dir);
        }
        return dir;
    }

    @Override
    public boolean estHumain(){return true;}
    @Override
    public String toString(){
        return String.format("\033[93m[Humain] "+this.nom()+"\033[0m");
    }
}


