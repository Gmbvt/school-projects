package projet;
import java.util.EnumMap;

public class Case{
    protected EnumMap<Directions, Case> voisins;    // Stockage des voisins de la case (HAUT, BAS, GAUCHE, DROITE)
    private Carte carte;                            // La case possède une carte
    private boolean estVide;                        // La case vide ne contient aucune carte

    Case(Carte carte){
        this.ajouterCarte(carte);
        this.voisins = new EnumMap<>(Directions.class);
    }
    public boolean estVide(){
        return this.estVide;
    }
    Carte obtenirCarte(){                           // Si case vide, renvoie la valeur nulle, sinon renvoie la carte
        if(!this.estVide()){
            return this.carte;
        }
        return null;        
    }
    Carte retirerCarte(){                           // Renvoie la carte est case considérée comme vide
        Carte aRenvoyer = new Carte(this.obtenirCarte().valeur());
        this.estVide = true;
        return aRenvoyer;
    }
    void ajouterCarte(Carte carte){                 // Changement de la carte dans la case et case considérée comme non-vide
        this.carte = carte;
        this.estVide = false;
    }

    void ajouterVoisins(Case voisin, Directions dir){   // Ajout du couple {Direction : voisin}
        this.voisins.put(dir, voisin);
    }

    Case voisinDe(Directions dir){
        return this.voisins.get(dir);
    }

    void decaler(Carte carte, Directions dir){  // Méthode récursive, prend en paramètre une carte et une direction

        if(this.obtenirCarte() != null){        // Si carte case non vide, appel de la méthode sur la case vers la direction dir
            this.voisins.get(dir).decaler(this.obtenirCarte(), dir);
        }
        this.ajouterCarte(carte);               // Carte précédente (carte) ajoutée dans la case
    }

    protected int score(){            // Si un voisin (HAUT, BAS, GAUCHE, DROITE) est de même valeur, la méthode renvoie 0, sinon elle renovoie la valeur de la carte qu'elle contient
        for(Directions i : voisins.keySet()){
            if(this.voisins.get(i) != null && this.obtenirCarte().valeur() == this.voisins.get(i).obtenirCarte().valeur()){
                return 0;
            }
        }
        return this.obtenirCarte().valeur();
    }
}



