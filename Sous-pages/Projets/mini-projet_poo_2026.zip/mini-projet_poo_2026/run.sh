javac -d build src/*.java
java -cp build projet.Jeu
